#!/usr/bin/bash

# before running this script, make sure conda environment is activated

cd ~/fundationmodel/RETFound || exit

input_size=256
batch_size=16
current_time=$(date "+%m_%d-%H_%M")

name='finetune' # Annotation for task

########## must be modified!
data_path="path/to/the/dataset"
model='dinov2_large'
nb_classes=5
########## must be modified!

task="zx-DINOV2-large-${current_time}-${batch_size}_${input_size}_${name}"

random_number=$((RANDOM % 90000 + 10000))
CUDA_VISIBLE_DEVICES=0 nohup torchrun --nproc_per_node=1 --master_port=$random_number retf_finetune.py \
--model $model \
--savemodel \
--global_pool \
--batch_size $batch_size \
--world_size 1 \
--epochs 300 \
--blr 5e-3 --layer_decay 0.65 \
--weight_decay 0.05 --drop_path 0.2 \
--nb_classes $nb_classes \
--data_path $data_path \
--input_size $input_size \
--task $task > "nohup/$task.log" &

