#!/usr/bin/bash

# before running this script, make sure conda environment is activated

cd /path/to/the/dinov2_eval || exit  # must be modified!

input_size=256
batch_size=16
current_time=$(date "+%m_%d-%H_%M")

name='test' # Annotation for task

########## must be modified!
nb_classes=5
data_path="path/to/the/dataset"
resume="dinov2_weights/DINOv2_L/Retina/checkpoint.pth"
model='dinov2_large'
########## must be modified!

task="DINOv2_test-${current_time}-${batch_size}_${input_size}_${name}"

random_number=$((RANDOM % 90000 + 10000))
CUDA_VISIBLE_DEVICES=0 nohup torchrun --nproc_per_node=1 --master_port=$random_number retf_finetune.py \
--model $model \
--eval \
--batch_size $batch_size \
--world_size 1 \
--epochs 50 \
--blr 5e-3 --layer_decay 0.65 \
--weight_decay 0.05 --drop_path 0.2 \
--nb_classes $nb_classes \
--data_path $data_path \
--task $task \
--resume $resume \
--input_size $input_size \
> nohup/$task.log &

