import math
import sys
import csv
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import LabelBinarizer
from timm.data import Mixup
from timm.utils import accuracy
from typing import Iterable, Optional
import util.misc as misc
import util.lr_sched as lr_sched
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score, average_precision_score, \
    multilabel_confusion_matrix, hamming_loss, jaccard_score, recall_score, precision_score, cohen_kappa_score
from pycm import *
import matplotlib.pyplot as plt
import numpy as np
# from vit_explain.vit_explain import attention_visualize
import time


def misc_measures(confusion_matrix):
    acc = []
    sensitivity = []
    specificity = []
    precision = []
    G = []
    F1_score_2 = []
    mcc_ = []

    for i in range(1, confusion_matrix.shape[0]):
        cm1 = confusion_matrix[i]
        acc.append(1. * (cm1[0, 0] + cm1[1, 1]) / np.sum(cm1))
        sensitivity_ = 1. * cm1[1, 1] / (cm1[1, 0] + cm1[1, 1])
        sensitivity.append(sensitivity_)
        specificity_ = 1. * cm1[0, 0] / (cm1[0, 1] + cm1[0, 0])
        specificity.append(specificity_)
        if cm1[1, 1] + cm1[0, 1] != 0:
            precision_ = 1. * cm1[1, 1] / (cm1[1, 1] + cm1[0, 1])
        else:
            precision_ = float('nan')
        precision.append(precision_)
        G.append(np.sqrt(sensitivity_ * specificity_))
        F1_score_2.append(2 * precision_ * sensitivity_ / (precision_ + sensitivity_))
        if (cm1[0, 0] + cm1[0, 1]) * (cm1[0, 0] + cm1[1, 0]) * (cm1[1, 1] + cm1[1, 0]) * (cm1[1, 1] + cm1[0, 1]) != 0:
            mcc = (cm1[0, 0] * cm1[1, 1] - cm1[0, 1] * cm1[1, 0]) / np.sqrt(
                (cm1[0, 0] + cm1[0, 1]) * (cm1[0, 0] + cm1[1, 0]) * (cm1[1, 1] + cm1[1, 0]) * (cm1[1, 1] + cm1[0, 1]))
        else:
            mcc = float('nan')
        mcc_.append(mcc)

    acc = np.array(acc).mean()
    sensitivity = np.array(sensitivity).mean()
    specificity = np.array(specificity).mean()
    precision = np.array(precision).mean()
    G = np.array(G).mean()
    F1_score_2 = np.array(F1_score_2).mean()
    mcc_ = np.array(mcc_).mean()

    return acc, sensitivity, specificity, precision, G, F1_score_2, mcc_


def train_one_epoch(model: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer=None,
                    args=None):
    model.train(True)
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = 20

    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):
        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)

        with torch.cuda.amp.autocast():
            outputs = model(samples)
            loss = criterion(outputs, targets)
        loss_value = loss.item()

        loss /= accum_iter
        loss_scaler(loss, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0)
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()

        torch.cuda.synchronize()

        metric_logger.update(loss=loss_value)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])

        metric_logger.update(lr=max_lr)

        loss_value_reduce = misc.all_reduce_mean(loss_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_1000x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss/train', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}


def train_one_epoch_decoder_only(model: torch.nn.Module, criterion: torch.nn.Module,
                                 data_loader: Iterable, optimizer: torch.optim.Optimizer,
                                 device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                                 mixup_fn: Optional[Mixup] = None, log_writer=None,
                                 args=None, linear_classifier=None, n=4):
    assert args.decoder_only
    model.train(True)
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = 20

    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):
        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)

        with torch.no_grad():
            output = model.get_intermediate_layers(samples, n)
        output = linear_classifier(output)

        with torch.cuda.amp.autocast():
            outputs = model(samples)
            loss = criterion(outputs, targets)
        loss_value = loss.item()

        loss /= accum_iter
        loss_scaler(loss, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0)
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()

        torch.cuda.synchronize()

        metric_logger.update(loss=loss_value)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])

        metric_logger.update(lr=max_lr)

        loss_value_reduce = misc.all_reduce_mean(loss_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_1000x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss/train', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}


def calculate_metrics_per_class(true_labels, pred_labels, writer, epoch):
    metrics = {}
    f1 = f1_score(true_labels, pred_labels, zero_division=0, average=None)
    roc = roc_auc_score(true_labels, pred_labels, average=None)
    precision = precision_score(true_labels, pred_labels, zero_division=0, average=None)
    recall = recall_score(true_labels, pred_labels, zero_division=0, average=None)
    true_labels = np.array(true_labels)
    pred_labels = np.array(pred_labels)

    classes_num = true_labels.shape[1]
    for i in range(classes_num):
        true_labels_i = [row[i] for row in true_labels]
        pred_labels_i = [row[i] for row in pred_labels]

        accuracy = accuracy_score(true_labels_i, pred_labels_i)

        kappa = cohen_kappa_score(true_labels_i, pred_labels_i)

        metrics[i] = {
            'Accuracy': accuracy,
            'F1 Score': f1[i],
            'ROC AUC': roc[i],
            'Precision': precision[i],
            'Recall': recall[i],
            'Cohen\'s Kappa': kappa
        }
        print(
            f'Class {i}: Accuracy: {accuracy:.4f}, F1 Score: {f1[i]:.4f}, ROC AUC: {roc[i]:.4f}, Precision: {precision[i]:.4f}, Recall: {recall[i]:.4f}, Kappa: {kappa:.4f}')
        if writer is not None:
            writer.add_scalar(f'Precision/{i}', precision[i], epoch)
            writer.add_scalar(f'Recall/{i}', recall[i], epoch)
            writer.add_scalar(f'F1 Score/{i}', f1[i], epoch)
            writer.add_scalar(f'Accuracy/{i}', accuracy, epoch)
            writer.add_scalar(f'ROC AUC/{i}', roc[i], epoch)
            writer.add_scalar(f'Cohen\'s Kappa/{i}', kappa, epoch)

    return metrics


@torch.no_grad()
def evaluate(data_loader, model, device, args, epoch, mode, num_class, log_writer):
    criterion = torch.nn.CrossEntropyLoss()

    metric_logger = misc.MetricLogger(delimiter="  ")
    header = mode + ':'

    os.makedirs(os.path.join(args.output_dir, args.task), exist_ok=True)

    true_onehot = []
    pred_onehot = []
    true_labels = []
    pred_labels = []
    pred_softmax = []

    # switch to evaluation mode
    model.eval()

    for batch in metric_logger.log_every(data_loader, 10, header):
        images = batch[0]
        target = batch[-1]
        images = images.to(device, non_blocking=True)
        target_label = target.to(device, non_blocking=True)
        target_onehot = F.one_hot(target_label.to(torch.int64), num_classes=num_class)
        # true_label = target

        # compute output
        with torch.cuda.amp.autocast():
            output = model(images)
            loss = criterion(output, target_label)
        # output_ = torch.softmax(output, dim=1)
        output_ = nn.Softmax(dim=1)(output)
        _, output_label = torch.max(output_, 1)
        output_onehot = F.one_hot(output_label.to(torch.int64), num_classes=num_class)

        # if mode == 'test':
        #     attention_visualize(model, images, None, 'min', 0.5)

        metric_logger.update(loss=loss.item())

        true_onehot.extend(target_onehot.cpu().numpy())
        pred_onehot.extend(output_onehot.detach().cpu().numpy())
        true_labels.extend(target_label.cpu().numpy())
        pred_labels.extend(output_label.detach().cpu().numpy())
        pred_softmax.extend(output_.detach().cpu().numpy())

    accuracy = accuracy_score(true_labels, pred_labels)
    hamming = hamming_loss(true_onehot, pred_onehot)
    jaccard = jaccard_score(true_onehot, pred_onehot, average='macro')
    average_precision = average_precision_score(true_onehot, pred_softmax, average='macro')
    kappa = cohen_kappa_score(true_labels, pred_labels)
    f1 = f1_score(true_onehot, pred_onehot, zero_division=0, average='macro')
    roc_auc = roc_auc_score(true_onehot, pred_softmax, multi_class='ovr', average='macro')
    precision = precision_score(true_onehot, pred_onehot, zero_division=0, average='macro')
    recall = recall_score(true_onehot, pred_onehot, zero_division=0, average='macro')

    # metrics = calculate_metrics_per_class(true_labels, pred_labels, log_writer, epoch)

    score = (f1 + roc_auc + kappa) / 3
    if log_writer is not None:
        log_writer.add_scalar('perf/accuracy', accuracy, epoch)
        log_writer.add_scalar('perf/f1', f1, epoch)
        log_writer.add_scalar('perf/roc_auc', roc_auc, epoch)
        log_writer.add_scalar('perf/hamming', hamming, epoch)
        log_writer.add_scalar('perf/jaccard', jaccard, epoch)
        log_writer.add_scalar('perf/precision', precision, epoch)
        log_writer.add_scalar('perf/recall', recall, epoch)
        log_writer.add_scalar('perf/average_precision', average_precision, epoch)
        log_writer.add_scalar('perf/kappa', kappa, epoch)
        log_writer.add_scalar('perf/score', score, epoch)
    print(f'val loss: {metric_logger.meters["loss"].global_avg}')
    print(f'Accuracy: {accuracy:.4f}, F1 Score: {f1:.4f}, ROC AUC: {roc_auc:.4f}, Hamming Loss: {hamming:.4f},\n'
          f' Jaccard Score: {jaccard:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f},'
          f' Average Precision: {average_precision:.4f}', f'Kappa: {kappa:.4f}', f'Score: {score:.4f}')

    # gather the stats from all processes

    metric_logger.synchronize_between_processes()

    if misc.is_main_process():
        results_path = os.path.join(args.output_dir, args.task, 'metrics_{}.csv'.format(mode))
        file_exists = os.path.isfile(results_path)
        with open(results_path, mode='a', newline='', encoding='utf8') as cfa:
            wf = csv.writer(cfa)
            if not file_exists:
                wf.writerow(['val_loss', 'accuracy', 'f1', 'roc_auc', 'hamming', 'jaccard', 'precision', 'recall',
                             'average_precision', 'kappa'])
            data2 = [
                [metric_logger.meters["loss"].global_avg, accuracy, f1, roc_auc, hamming, jaccard, precision, recall,
                 average_precision, kappa]]
            for i in data2:
                wf.writerow(i)

        if mode == 'test':
            results_path = os.path.join(args.output_dir, 'retf_vs_dinov2_test.csv')
            file_exists = os.path.isfile(results_path)
            with open(results_path, mode='a', newline='', encoding='utf8') as cfa:
                wf = csv.writer(cfa)
                if not file_exists:
                    wf.writerow(
                        ['task', 'test_loss', 'accuracy', 'f1', 'roc_auc', 'hamming', 'jaccard', 'precision', 'recall',
                         'average_precision', 'kappa', 'score'])
                data2 = [
                    [args.task + '_' + ('best' if epoch == -1 else 'latest'), metric_logger.meters["loss"].global_avg,
                     accuracy, f1, roc_auc, hamming, jaccard, precision,
                     recall,
                     average_precision, kappa, score]]
                for i in data2:
                    wf.writerow(i)

    true_labels = np.array(true_labels)
    pred_labels = np.array(pred_labels)

    if mode == 'test':
        cm = ConfusionMatrix(actual_vector=true_labels, predict_vector=pred_labels)
        cm.plot(cmap=plt.cm.Blues, number_label=True, normalized=True, plot_lib="matplotlib")
        plt.savefig(os.path.join(args.output_dir, args.task, 'confusion_matrix_test.jpg'), dpi=600, bbox_inches='tight')

    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}, score
