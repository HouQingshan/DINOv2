# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
# Partly revised by YZ @UCL&Moorfields
# --------------------------------------------------------

from functools import partial

import timm.models.vision_transformer
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


# from main_finetune import get_args_parser
#
# args = get_args_parser().parse_args()


class VisionTransformer(timm.models.vision_transformer.VisionTransformer):
    """ Vision Transformer with support for global average pooling
    """

    def __init__(self, global_pool_c=False, **kwargs):
        super(VisionTransformer, self).__init__(**kwargs)

        self.global_pool = global_pool_c
        if self.global_pool:
            norm_layer = kwargs['norm_layer']
            embed_dim = kwargs['embed_dim']
            self.fc_norm = norm_layer(embed_dim)

            del self.norm  # remove the original norm
        self.head = nn.Linear(self.head.in_features, 8)

    def forward_features(self, x, return_all_tokens=False):
        B = x.shape[0]
        x = self.patch_embed(x)

        cls_tokens = self.cls_token.expand(B, -1, -1)  # stole cls_tokens impl from Phil Wang, thanks
        x = torch.cat((cls_tokens, x), dim=1)
        x = x + self.pos_embed
        x = self.pos_drop(x)

        for blk in self.blocks:
            x = blk(x)

        output = x

        if self.global_pool:
            x = x[:, 1:, :].mean(dim=1).unsqueeze(1)  # global pool without cls token
            outcome = self.fc_norm(x)
        else:
            x = self.norm(x)
            outcome = x[:, 0]

        if return_all_tokens:
            return outcome, output

        return outcome

    def forward(self, x: torch.Tensor, return_features=False, features_head='linear', feat_dim=None,
                mode='cls') -> tuple[Tensor, Tensor] | Tensor:
        x, f = self.forward_features(x, return_all_tokens=True)
        x = self.forward_head(x)

        if return_features:
            if features_head == 'linear':
                self.feature_head = nn.Linear(self.embed_dim * 2 if mode == 'concat' else self.embed_dim, feat_dim).to(
                    x.device)
            elif features_head == 'mlp':
                self.feature_head = nn.Sequential(
                    nn.Linear(self.embed_dim * 2 if mode == 'concat' else self.embed_dim, self.embed_dim),
                    nn.ReLU(inplace=True),
                    nn.Linear(self.embed_dim, feat_dim)
                ).to(x.device)
            elif features_head == 'identity':
                self.feature_head = nn.Identity().to(x.device)
            else:
                raise NotImplementedError(
                    f'head not supported: {features_head}')

            if mode == 'cls':
                return x, F.normalize(self.feature_head(f[:, 0]), dim=1)
            elif mode == 'mean':
                return x, F.normalize(self.feature_head(f[:, 1:].mean(dim=1)), dim=1)
            elif mode == 'concat':
                return x, F.normalize(self.feature_head(torch.cat(
                    (f[:, 0], f[:, 1:].mean(dim=1)), dim=1)
                ), dim=1)
            else:
                raise NotImplementedError(
                    f'mode not supported: {mode}')
        return x


def vit_large_patch16(args, **kwargs):
    model = VisionTransformer(global_pool_c=args.global_pool,
                              img_size=args.input_size, patch_size=16, embed_dim=1024, depth=24, num_heads=16,
                              mlp_ratio=4, global_pool='',
                              qkv_bias=True, norm_layer=partial(nn.LayerNorm, eps=1e-6), **kwargs)
    return model


def dinov2_large(args, **kwargs):
    model = timm.create_model(
        'vit_large_patch14_dinov2.lvd142m',
        pretrained=True,
        img_size=args.input_size,
        **kwargs
    )
    return model


def dinov2_base(args, **kwargs):
    model = timm.create_model(
        'vit_base_patch14_dinov2.lvd142m',
        pretrained=True,
        img_size=args.input_size,
        **kwargs
    )
    return model

def dinov2_small(args, **kwargs):
    model = timm.create_model(
        'vit_small_patch14_dinov2.lvd142m',
        pretrained=True,
        img_size=args.input_size,
        **kwargs
    )
    return model


def resnet50(args, **kwargs):
    model = timm.create_model(
        'resnet50',
        pretrained=True,
        **kwargs
    )
    return model


def resnet101(args, **kwargs):
    model = timm.create_model(
        'resnet101',
        pretrained=True,
        **kwargs
    )
    return model


def vit_large_patch16_ori(args, **kwargs):
    model = timm.create_model(
        'vit_large_patch16_224',
        pretrained=True,
        img_size=args.input_size,
        **kwargs
    )
    return model

def vit_base_patch16_ori(args, **kwargs):
    model = timm.create_model(
        'vit_base_patch16_224',
        pretrained=True,
        img_size=args.input_size,
        **kwargs
    )
    return model


def vit_small_patch16_ori(args, **kwargs):
    model = timm.create_model(
        'vit_small_patch16_224',
        pretrained=True,
        img_size=args.input_size,
        **kwargs
    )
    return model


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='ViT')
    parser.add_argument('--global_pool', default=True, type=str, help='Global pooling method')
    parser.add_argument('--input_size', type=int, default=224, help='input size')
    args = parser.parse_args()
    batch = torch.rand((10, 3, 224, 224))
    # model = resnet50(args=dict(global_pool=False),
    #                  num_classes=8,
    #                  drop_path_rate=0.25, )

    # output = model(batch)
    # print(output.shape)
    # print(model)

    model = vit_base_patch16_ori(
        num_classes=8,
        drop_path_rate=0.25,
        args=args)

    y, f = model(batch, return_features=True, features_head='linear', feat_dim=128, mode='cls')

    feat = model.get_features(batch)
    print(y.shape, f.shape)

    # for name, param in model.named_parameters():
    #     print(f"Parameter name: {name}")
    # print(f"Parameter shape: {param.shape}\n")
