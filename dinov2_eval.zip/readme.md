1. Create a conda environment with the following command:

    ```
    conda create -n dinov2_eval python=3.11 -y
    conda activate dinov2_eval
    pip install -r requirements.txt
    ```
2. Organise your data into this directory structure

    ```
    ├── data folder
        ├──train
            ├──class_a
            ├──class_b
            ├──class_c
        ├──val
            ├──class_a
            ├──class_b
            ├──class_c
        ├──test
            ├──class_a
            ├──class_b
            ├──class_c
    ``` 

2. Modify the key parameters in the eval_dinov2.sh
    ```
    cd ~/path/to/the/dinov2_eval || exit   # the main directory of the project
   
    nb_classes=5   # number of classes in the dataset
    data_path="path/to/the/data folder"
    resume="dinov2_weights/DINOv2_L/Retina/checkpoint.pth"
    model='dinov2_large'  # 'dinov2_small' or 'dinov2_large'
    ```
3. Give permission to the script in the terminal
    
    ```
    chmod +x eval_dinov2.sh
    ```
4. Run the script in the terminal

    ```
    ./eval_dinov2.sh
    ```
